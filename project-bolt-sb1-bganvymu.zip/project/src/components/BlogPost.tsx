import React, { useState } from 'react';
import { Heart, MessageCircle, Share, MoreHorizontal, Calendar } from 'lucide-react';
import { BlogPost as BlogPostType, Comment } from '../types/blog';
import { currentUser } from '../data/mockData';
import CommentSection from './CommentSection';

interface BlogPostProps {
  post: BlogPostType;
  onLike: (postId: string) => void;
  onComment: (postId: string, content: string) => void;
}

export default function BlogPost({ post, onLike, onComment }: BlogPostProps) {
  const [showComments, setShowComments] = useState(false);
  const [isLiked, setIsLiked] = useState(post.likes.includes(currentUser.id));
  const [likeCount, setLikeCount] = useState(post.likes.length);

  const handleLike = () => {
    setIsLiked(!isLiked);
    setLikeCount(prev => isLiked ? prev - 1 : prev + 1);
    onLike(post.id);
  };

  const handleComment = (content: string) => {
    onComment(post.id, content);
  };

  const formatDate = (date: Date) => {
    return new Intl.DateTimeFormat('en-US', {
      month: 'short',
      day: 'numeric',
      year: 'numeric',
    }).format(date);
  };

  return (
    <article className="bg-white rounded-2xl shadow-md hover:shadow-lg transition-shadow duration-300 overflow-hidden">
      {/* Header */}
      <div className="p-6 pb-4">
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center space-x-3">
            <img
              src={post.user.avatar}
              alt={post.user.name}
              className="w-12 h-12 rounded-full object-cover"
            />
            <div>
              <h3 className="font-semibold text-gray-900">{post.user.name}</h3>
              <div className="flex items-center space-x-2 text-sm text-gray-500">
                <span>@{post.user.username}</span>
                <span>•</span>
                <div className="flex items-center space-x-1">
                  <Calendar className="w-3 h-3" />
                  <span>{formatDate(post.createdAt)}</span>
                </div>
              </div>
            </div>
          </div>
          <button className="text-gray-400 hover:text-gray-600 transition-colors">
            <MoreHorizontal className="w-5 h-5" />
          </button>
        </div>

        {/* Title */}
        <h2 className="text-xl font-bold text-gray-900 mb-3 leading-tight">
          {post.title}
        </h2>

        {/* Content */}
        <p className="text-gray-700 leading-relaxed mb-4">
          {post.content}
        </p>

        {/* Tags */}
        {post.tags.length > 0 && (
          <div className="flex flex-wrap gap-2 mb-4">
            {post.tags.map((tag) => (
              <span
                key={tag}
                className="text-blue-600 text-sm hover:text-blue-800 cursor-pointer transition-colors"
              >
                #{tag}
              </span>
            ))}
          </div>
        )}
      </div>

      {/* Image */}
      {post.image && (
        <div className="px-6 pb-4">
          <img
            src={post.image}
            alt={post.title}
            className="w-full h-64 sm:h-80 object-cover rounded-xl"
          />
        </div>
      )}

      {/* Actions */}
      <div className="px-6 pb-4">
        <div className="flex items-center justify-between pt-4 border-t border-gray-100">
          <div className="flex items-center space-x-6">
            <button
              onClick={handleLike}
              className={`flex items-center space-x-2 transition-colors duration-200 ${
                isLiked 
                  ? 'text-red-500 hover:text-red-600' 
                  : 'text-gray-500 hover:text-red-500'
              }`}
            >
              <Heart 
                className={`w-5 h-5 transition-transform duration-200 ${
                  isLiked ? 'fill-current scale-110' : 'hover:scale-110'
                }`} 
              />
              <span className="text-sm font-medium">{likeCount}</span>
            </button>
            
            <button
              onClick={() => setShowComments(!showComments)}
              className="flex items-center space-x-2 text-gray-500 hover:text-blue-600 transition-colors duration-200"
            >
              <MessageCircle className="w-5 h-5" />
              <span className="text-sm font-medium">{post.comments.length}</span>
            </button>
          </div>

          <button className="flex items-center space-x-2 text-gray-500 hover:text-green-600 transition-colors duration-200">
            <Share className="w-5 h-5" />
            <span className="text-sm font-medium">Share</span>
          </button>
        </div>
      </div>

      {/* Comments Section */}
      {showComments && (
        <CommentSection
          comments={post.comments}
          onAddComment={handleComment}
        />
      )}
    </article>
  );
}