import React from 'react';
import { TrendingUp, Hash, Users, Bookmark } from 'lucide-react';
import { currentUser } from '../data/mockData';

export default function Sidebar() {
  const trendingTags = [
    { tag: 'react', count: 245 },
    { tag: 'javascript', count: 189 },
    { tag: 'webdev', count: 156 },
    { tag: 'programming', count: 134 },
    { tag: 'nodejs', count: 98 }
  ];

  const suggestedUsers = [
    { name: 'John Doe', username: 'johndoe', followers: '1.2k' },
    { name: 'Jane Smith', username: 'janesmith', followers: '856' },
    { name: 'Bob Wilson', username: 'bobwilson', followers: '642' }
  ];

  return (
    <aside className="w-80 bg-white rounded-2xl shadow-md p-6 h-fit sticky top-24">
      {/* User Profile */}
      <div className="mb-8">
        <div className="flex items-center space-x-3 mb-4">
          <img
            src={currentUser.avatar}
            alt={currentUser.name}
            className="w-12 h-12 rounded-full object-cover"
          />
          <div>
            <h3 className="font-semibold text-gray-900">{currentUser.name}</h3>
            <p className="text-sm text-gray-500">@{currentUser.username}</p>
          </div>
        </div>
        <p className="text-sm text-gray-600 mb-4">{currentUser.bio}</p>
        <div className="flex space-x-4 text-sm">
          <span><strong>12</strong> Posts</span>
          <span><strong>1.2k</strong> Followers</span>
          <span><strong>489</strong> Following</span>
        </div>
      </div>

      {/* Trending Tags */}
      <div className="mb-8">
        <div className="flex items-center space-x-2 mb-4">
          <TrendingUp className="w-5 h-5 text-orange-500" />
          <h3 className="font-semibold text-gray-900">Trending Tags</h3>
        </div>
        <div className="space-y-3">
          {trendingTags.map((item, index) => (
            <div key={item.tag} className="flex items-center justify-between p-2 hover:bg-gray-50 rounded-lg cursor-pointer transition-colors">
              <div className="flex items-center space-x-2">
                <span className="text-sm font-medium text-gray-500">#{index + 1}</span>
                <Hash className="w-4 h-4 text-gray-400" />
                <span className="font-medium text-gray-900">{item.tag}</span>
              </div>
              <span className="text-sm text-gray-500">{item.count} posts</span>
            </div>
          ))}
        </div>
      </div>

      {/* Suggested Users */}
      <div>
        <div className="flex items-center space-x-2 mb-4">
          <Users className="w-5 h-5 text-purple-500" />
          <h3 className="font-semibold text-gray-900">Suggested for You</h3>
        </div>
        <div className="space-y-3">
          {suggestedUsers.map((user) => (
            <div key={user.username} className="flex items-center justify-between p-2 hover:bg-gray-50 rounded-lg transition-colors">
              <div className="flex items-center space-x-3">
                <div className="w-8 h-8 bg-gradient-to-br from-blue-400 to-purple-500 rounded-full flex items-center justify-center text-white font-medium text-sm">
                  {user.name.charAt(0)}
                </div>
                <div>
                  <p className="font-medium text-gray-900 text-sm">{user.name}</p>
                  <p className="text-xs text-gray-500">{user.followers} followers</p>
                </div>
              </div>
              <button className="px-3 py-1 bg-blue-600 text-white text-xs rounded-full hover:bg-blue-700 transition-colors">
                Follow
              </button>
            </div>
          ))}
        </div>
      </div>
    </aside>
  );
}