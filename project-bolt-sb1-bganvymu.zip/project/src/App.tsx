import React, { useState, useMemo } from 'react';
import { BlogPost, CreatePostData, Comment } from './types/blog';
import { mockPosts, currentUser, users } from './data/mockData';
import Header from './components/Header';
import BlogPostComponent from './components/BlogPost';
import CreatePostModal from './components/CreatePostModal';
import Sidebar from './components/Sidebar';

function App() {
  const [posts, setPosts] = useState<BlogPost[]>(mockPosts);
  const [isCreateModalOpen, setIsCreateModalOpen] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');

  // Filter posts based on search query
  const filteredPosts = useMemo(() => {
    if (!searchQuery.trim()) return posts;
    
    const query = searchQuery.toLowerCase();
    return posts.filter(post => 
      post.title.toLowerCase().includes(query) ||
      post.content.toLowerCase().includes(query) ||
      post.tags.some(tag => tag.toLowerCase().includes(query)) ||
      post.user.name.toLowerCase().includes(query) ||
      post.user.username.toLowerCase().includes(query)
    );
  }, [posts, searchQuery]);

  const handleCreatePost = (postData: CreatePostData) => {
    const newPost: BlogPost = {
      id: `post-${Date.now()}`,
      user: currentUser,
      title: postData.title,
      content: postData.content,
      image: postData.image,
      likes: [],
      comments: [],
      createdAt: new Date(),
      tags: postData.tags
    };

    setPosts(prev => [newPost, ...prev]);
  };

  const handleLike = (postId: string) => {
    setPosts(prev => prev.map(post => {
      if (post.id === postId) {
        const isLiked = post.likes.includes(currentUser.id);
        return {
          ...post,
          likes: isLiked 
            ? post.likes.filter(id => id !== currentUser.id)
            : [...post.likes, currentUser.id]
        };
      }
      return post;
    }));
  };

  const handleComment = (postId: string, content: string) => {
    const newComment: Comment = {
      id: `comment-${Date.now()}`,
      user: currentUser,
      content,
      createdAt: new Date()
    };

    setPosts(prev => prev.map(post => 
      post.id === postId 
        ? { ...post, comments: [...post.comments, newComment] }
        : post
    ));
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <Header 
        onCreatePost={() => setIsCreateModalOpen(true)}
        searchQuery={searchQuery}
        onSearchChange={setSearchQuery}
      />
      
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="grid grid-cols-1 lg:grid-cols-4 gap-8">
          {/* Main Content */}
          <div className="lg:col-span-3">
            {searchQuery && (
              <div className="mb-6">
                <h2 className="text-lg font-semibold text-gray-900">
                  Search results for "{searchQuery}" ({filteredPosts.length} found)
                </h2>
              </div>
            )}
            
            <div className="space-y-6">
              {filteredPosts.length > 0 ? (
                filteredPosts.map((post) => (
                  <BlogPostComponent
                    key={post.id}
                    post={post}
                    onLike={handleLike}
                    onComment={handleComment}
                  />
                ))
              ) : (
                <div className="text-center py-12">
                  <div className="w-16 h-16 bg-gray-200 rounded-full flex items-center justify-center mx-auto mb-4">
                    <span className="text-2xl">🔍</span>
                  </div>
                  <h3 className="text-lg font-medium text-gray-900 mb-2">
                    No posts found
                  </h3>
                  <p className="text-gray-500">
                    Try adjusting your search terms or browse all posts.
                  </p>
                </div>
              )}
            </div>
          </div>

          {/* Sidebar */}
          <div className="hidden lg:block">
            <Sidebar />
          </div>
        </div>
      </main>

      <CreatePostModal
        isOpen={isCreateModalOpen}
        onClose={() => setIsCreateModalOpen(false)}
        onSubmit={handleCreatePost}
      />
    </div>
  );
}

export default App;