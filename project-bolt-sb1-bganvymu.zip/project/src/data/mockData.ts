import { BlogPost, User } from '../types/blog';
import { Notification } from '../types/blog';

export const currentUser: User = {
  id: 'user-1',
  name: 'Anushka Bohra',
  username: 'anushkabohra',
  avatar: 'https://i.ytimg.com/vi/eXwZMAz9Vh8/maxresdefault.jpg',
  bio: 'handle with care'
};

export const users: User[] = [
  currentUser,
  {
    id: 'user-2',
    name: 'Anushree',
    username: 'ilovesanvi',
    avatar: 'https://i.pinimg.com/originals/ea/e8/7f/eae87f33d03cadd42c484556f8718491.jpg',
    bio: 'I LOVE ANUSHKA'
  },
  {
    id: 'user-3',
    name: 'sanvi',
    username: 'iloveanushree',
    avatar: 'https://tse1.explicit.bing.net/th/id/OIP._1UB7K1NWowEBEKdLOvXgAHaHa?rs=1&pid=ImgDetMain&o=7&rm=3',
    bio: 'I LOVE ANUSHKA'
  },
  {
    id: 'user-4',
    name: 'diya',
    username: 'iloveeveryone',
    avatar: 'https://i.pinimg.com/originals/0a/21/3f/0a213f304e65a9f00aa465e611aacaed.png',
    bio: 'I LOVE ANUSHKA'
  }
];

export const mockPosts: BlogPost[] = [
  {
    id: 'post-1',
    user: users[1],
    title: 'Exploring the Swiss Alps: A Journey Through Paradise',
    content: 'Just returned from an incredible week hiking through the Swiss Alps. The pristine mountain lakes, snow-capped peaks, and charming villages made this trip absolutely unforgettable. Here are some highlights from my adventure...',
    image: 'https://images.pexels.com/photos/1757363/pexels-photo-1757363.jpeg?auto=compress&cs=tinysrgb&w=800&h=600&fit=crop',
    likes: ['user-1', 'user-3', 'user-4'],
    comments: [
      {
        id: 'comment-1',
        user: users[0],
        content: 'Absolutely stunning photos! The Alps have always been on my bucket list.',
        createdAt: new Date('2024-01-15T10:30:00Z')
      },
      {
        id: 'comment-2',
        user: users[2],
        content: 'Those mountain views are incredible. How was the weather during your hike?',
        createdAt: new Date('2024-01-15T11:45:00Z')
      }
    ],
    createdAt: new Date('2024-01-15T08:00:00Z'),
    tags: ['travel', 'hiking', 'switzerland', 'mountains']
  },
  {
    id: 'post-2',
    user: users[2],
    title: 'The Art of Homemade Pasta: A Culinary Journey',
    content: 'There\'s something magical about creating pasta from scratch. Today I\'m sharing my grandmother\'s secret recipe for the perfect tagliatelle, passed down through three generations of Italian cooking...',
    image: 'https://images.pexels.com/photos/1279330/pexels-photo-1279330.jpeg?auto=compress&cs=tinysrgb&w=800&h=600&fit=crop',
    likes: ['user-1', 'user-2'],
    comments: [
      {
        id: 'comment-3',
        user: users[3],
        content: 'This looks absolutely delicious! Would love to try the recipe.',
        createdAt: new Date('2024-01-14T15:20:00Z')
      }
    ],
    createdAt: new Date('2024-01-14T12:00:00Z'),
    tags: ['food', 'cooking', 'italian', 'pasta', 'recipe']
  },
  {
    id: 'post-3',
    user: users[3],
    title: 'Building the Future: AI and Startup Innovation',
    content: 'The intersection of artificial intelligence and entrepreneurship is creating unprecedented opportunities. In this post, I explore how startups are leveraging AI to solve complex problems and create value...',
    image: 'https://images.pexels.com/photos/3184465/pexels-photo-3184465.jpeg?auto=compress&cs=tinysrgb&w=800&h=600&fit=crop',
    likes: ['user-1'],
    comments: [],
    createdAt: new Date('2024-01-13T14:30:00Z'),
    tags: ['technology', 'ai', 'startup', 'innovation', 'business']
  },
  {
    id: 'post-4',
    user: users[0],
    title: 'Mastering React Performance: Tips and Tricks',
    content: 'Performance optimization in React applications is crucial for delivering great user experiences. Here are some advanced techniques I\'ve learned that can dramatically improve your app\'s performance...',
    image: 'https://images.pexels.com/photos/574077/pexels-photo-574077.jpeg?auto=compress&cs=tinysrgb&w=800&h=600&fit=crop',
    likes: ['user-2', 'user-3', 'user-4'],
    comments: [
      {
        id: 'comment-4',
        user: users[1],
        content: 'Great insights! The section on memo usage was particularly helpful.',
        createdAt: new Date('2024-01-12T16:45:00Z')
      }
    ],
    createdAt: new Date('2024-01-12T09:15:00Z'),
    tags: ['programming', 'react', 'performance', 'webdev', 'javascript']
  }
];

export const mockNotifications: Notification[] = [
  {
    id: 'notif-1',
    type: 'like',
    user: users[1],
    message: 'liked your post "Mastering React Performance"',
    postId: 'post-4',
    createdAt: new Date('2024-01-15T14:30:00Z'),
    read: false
  },
  {
    id: 'notif-2',
    type: 'comment',
    user: users[2],
    message: 'commented on your post "Mastering React Performance"',
    postId: 'post-4',
    createdAt: new Date('2024-01-15T12:15:00Z'),
    read: false
  },
  {
    id: 'notif-3',
    type: 'follow',
    user: users[3],
    message: 'started following you',
    createdAt: new Date('2024-01-14T16:45:00Z'),
    read: false
  },
  {
    id: 'notif-4',
    type: 'like',
    user: users[1],
    message: 'liked your post "Building the Future: AI and Startup Innovation"',
    postId: 'post-3',
    createdAt: new Date('2024-01-14T10:20:00Z'),
    read: true
  },
  {
    id: 'notif-5',
    type: 'mention',
    user: users[2],
    message: 'mentioned you in a comment',
    postId: 'post-2',
    createdAt: new Date('2024-01-13T18:30:00Z'),
    read: true
  }
];