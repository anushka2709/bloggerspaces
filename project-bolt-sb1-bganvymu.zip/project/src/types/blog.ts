export interface User {
  id: string;
  name: string;
  username: string;
  avatar: string;
  bio?: string;
}

export interface Comment {
  id: string;
  user: User;
  content: string;
  createdAt: Date;
}

export interface BlogPost {
  id: string;
  user: User;
  title: string;
  content: string;
  image?: string;
  likes: string[];
  comments: Comment[];
  createdAt: Date;
  tags: string[];
}

export interface Notification {
  id: string;
  type: 'like' | 'comment' | 'follow' | 'mention';
  user: User;
  message: string;
  postId?: string;
  createdAt: Date;
  read: boolean;
}
export interface CreatePostData {
  title: string;
  content: string;
  image?: string;
  tags: string[];
}